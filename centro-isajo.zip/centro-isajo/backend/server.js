const express = require('express');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./db');

const app = express();
const PORT = 3000;
const SECRET_KEY = 'clave_secreta_isajo_2025_cambiar_en_produccion';

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// =============================================
// RUTAS DE AUTENTICACIÓN
// =============================================

// Login de Usuario Ordinario (por nombre y RUT)
app.post('/api/auth/usuario', async (req, res) => {
    const { nombre, rut } = req.body;
    
    try {
        // Buscar o crear usuario
        let [users] = await db.query('SELECT * FROM usuarios WHERE rut = ?', [rut]);
        
        if (users.length === 0) {
            // Registrar nuevo usuario
            const [result] = await db.query(
                'INSERT INTO usuarios (nombre, rut) VALUES (?, ?)',
                [nombre, rut]
            );
            const token = jwt.sign({ id: result.insertId, rut, rol: 'usuario' }, SECRET_KEY, { expiresIn: '24h' });
            return res.json({ success: true, token, rol: 'usuario', nombre });
        }
        
        const usuario = users[0];
        if (usuario.nombre.toLowerCase() !== nombre.toLowerCase()) {
            return res.status(401).json({ success: false, message: 'Nombre no coincide con el RUT' });
        }
        
        const token = jwt.sign({ id: usuario.id, rut: usuario.rut, rol: 'usuario' }, SECRET_KEY, { expiresIn: '24h' });
        res.json({ success: true, token, rol: 'usuario', nombre: usuario.nombre });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error en el servidor' });
    }
});

// Login de Profesional (email + clave única)
app.post('/api/auth/profesional', async (req, res) => {
    const { email, clave_unica } = req.body;
    
    try {
        const [profesionales] = await db.query(
            'SELECT * FROM profesionales WHERE email = ? AND activo = 1',
            [email]
        );
        
        if (profesionales.length === 0) {
            return res.status(401).json({ success: false, message: 'Credenciales incorrectas' });
        }
        
        const profesional = profesionales[0];
        
        // Comparar contraseña (en producción usar bcrypt)
        if (clave_unica !== profesional.clave_unica) {
            return res.status(401).json({ success: false, message: 'Credenciales incorrectas' });
        }
        
        const token = jwt.sign(
            { id: profesional.id, email: profesional.email, rol: 'profesional', nombre: profesional.nombre },
            SECRET_KEY,
            { expiresIn: '8h' }
        );
        
        res.json({
            success: true,
            token,
            rol: 'profesional',
            nombre: profesional.nombre,
            especialidad: profesional.especialidad
        });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error en el servidor' });
    }
});

// Login de Administrador
app.post('/api/auth/admin', async (req, res) => {
    const { usuario, password } = req.body;
    
    try {
        const [admins] = await db.query('SELECT * FROM administradores WHERE usuario = ?', [usuario]);
        
        if (admins.length === 0) {
            return res.status(401).json({ success: false, message: 'Credenciales incorrectas' });
        }
        
        const admin = admins[0];
        
        // Comparar contraseña (en producción usar bcrypt)
        if (password !== admin.password_hash) {
            return res.status(401).json({ success: false, message: 'Credenciales incorrectas' });
        }
        
        const token = jwt.sign({ id: admin.id, usuario: admin.usuario, rol: 'admin' }, SECRET_KEY, { expiresIn: '12h' });
        
        res.json({ success: true, token, rol: 'admin', usuario: admin.usuario });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error en el servidor' });
    }
});

// Middleware para verificar token
const verificarToken = (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1];
    
    if (!token) {
        return res.status(401).json({ success: false, message: 'Token no proporcionado' });
    }
    
    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        req.usuario = decoded;
        next();
    } catch (error) {
        return res.status(401).json({ success: false, message: 'Token inválido' });
    }
};

// =============================================
// RUTAS DE RESERVAS
// =============================================

// Obtener reservas de un usuario (por RUT)
app.get('/api/reservas/usuario/:rut', verificarToken, async (req, res) => {
    const { rut } = req.params;
    
    try {
        const [reservas] = await db.query(
            `SELECT r.*, p.nombre as profesional_nombre, p.especialidad 
             FROM reservas r
             LEFT JOIN profesionales p ON r.profesional_id = p.id
             WHERE r.usuario_rut = ?
             ORDER BY r.fecha DESC, r.hora DESC`,
            [rut]
        );
        res.json({ success: true, reservas });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error al obtener reservas' });
    }
});

// Obtener reservas de un profesional
app.get('/api/reservas/profesional/:id', verificarToken, async (req, res) => {
    const { id } = req.params;
    
    try {
        const [reservas] = await db.query(
            `SELECT r.*, u.nombre as paciente_nombre, u.rut as paciente_rut
             FROM reservas r
             LEFT JOIN usuarios u ON r.usuario_rut = u.rut
             WHERE r.profesional_id = ?
             ORDER BY r.fecha DESC, r.hora DESC`,
            [id]
        );
        res.json({ success: true, reservas });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error al obtener reservas' });
    }
});

// Obtener todas las reservas (solo admin)
app.get('/api/reservas/todas', verificarToken, async (req, res) => {
    if (req.usuario.rol !== 'admin') {
        return res.status(403).json({ success: false, message: 'Acceso denegado' });
    }
    
    try {
        const [reservas] = await db.query(
            `SELECT r.*, u.nombre as paciente_nombre, u.rut as paciente_rut, p.nombre as profesional_nombre
             FROM reservas r
             LEFT JOIN usuarios u ON r.usuario_rut = u.rut
             LEFT JOIN profesionales p ON r.profesional_id = p.id
             ORDER BY r.fecha DESC, r.hora DESC`
        );
        res.json({ success: true, reservas });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error al obtener reservas' });
    }
});

// Crear nueva reserva
app.post('/api/reservas', verificarToken, async (req, res) => {
    const { usuario_rut, profesional_id, fecha, hora, especialidad } = req.body;
    
    try {
        const [result] = await db.query(
            `INSERT INTO reservas (usuario_rut, profesional_id, fecha, hora, especialidad, estado)
             VALUES (?, ?, ?, ?, ?, 'pendiente')`,
            [usuario_rut, profesional_id, fecha, hora, especialidad]
        );
        res.json({ success: true, reserva_id: result.insertId });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error al crear reserva' });
    }
});

// Actualizar estado de reserva
app.put('/api/reservas/:id/estado', verificarToken, async (req, res) => {
    const { id } = req.params;
    const { estado } = req.body;
    
    try {
        await db.query('UPDATE reservas SET estado = ? WHERE id = ?', [estado, id]);
        res.json({ success: true, message: 'Estado actualizado' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error al actualizar' });
    }
});

// =============================================
// RUTAS PARA ADMIN (CRUD completo)
// =============================================

// Obtener todos los usuarios
app.get('/api/admin/usuarios', verificarToken, async (req, res) => {
    if (req.usuario.rol !== 'admin') return res.status(403).json({ success: false });
    
    try {
        const [usuarios] = await db.query('SELECT * FROM usuarios ORDER BY id DESC');
        res.json({ success: true, usuarios });
    } catch (error) {
        res.status(500).json({ success: false });
    }
});

// Obtener todos los profesionales
app.get('/api/admin/profesionales', verificarToken, async (req, res) => {
    if (req.usuario.rol !== 'admin') return res.status(403).json({ success: false });
    
    try {
        const [profesionales] = await db.query('SELECT * FROM profesionales ORDER BY id DESC');
        res.json({ success: true, profesionales });
    } catch (error) {
        res.status(500).json({ success: false });
    }
});

// Crear profesional (admin)
app.post('/api/admin/profesionales', verificarToken, async (req, res) => {
    if (req.usuario.rol !== 'admin') return res.status(403).json({ success: false });
    
    const { nombre, rut, especialidad, email, clave_unica } = req.body;
    
    try {
        const [result] = await db.query(
            'INSERT INTO profesionales (nombre, rut, especialidad, email, clave_unica) VALUES (?, ?, ?, ?, ?)',
            [nombre, rut, especialidad, email, clave_unica]
        );
        res.json({ success: true, id: result.insertId });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// Eliminar profesional
app.delete('/api/admin/profesionales/:id', verificarToken, async (req, res) => {
    if (req.usuario.rol !== 'admin') return res.status(403).json({ success: false });
    
    try {
        await db.query('DELETE FROM profesionales WHERE id = ?', [req.params.id]);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false });
    }
});

// =============================================
// INICIAR SERVIDOR
// =============================================
app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
    console.log(`📱 Accede a la página web en http://localhost:${PORT}/login.html`);
});