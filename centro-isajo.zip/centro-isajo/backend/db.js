const mysql = require('mysql2');

// Configuración de conexión a MySQL
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',           // Cambia si tu usuario es diferente
    password: '',           // En XAMPP es vacío, en MySQL instalado tu contraseña
    database: 'centro_isajo',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

const promisePool = pool.promise();

module.exports = promisePool;